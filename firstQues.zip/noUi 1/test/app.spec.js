
import {expect} from 'chai';
import {ShoppingCart} from '../app';


//First Ques
describe('Add products to the shopping cart', () => {
      let result = new ShoppingCart();// Create Empty Shopping Cart
      result.addProduct({unit:5,price:'39.99',productName:'Dove', productId:'prod1'});

    it('should corrrectly calculate  cart’s total price', () => {
    expect(result.getTotal()).to.equal('199.95');
    expect(result.getCart().length).to.equal(1);
    
})
    it('should corrrectly calculate  cart’s item specifications', () => {
      
        expect(result.getCart().length).to.equal(1);
        expect(result.getCart()[0].productName).to.equal('Dove');
        expect(result.getCart()[0].price).to.equal('39.99');
        expect(result.getCart()[0].unit).to.equal(5);
       
    })
})

