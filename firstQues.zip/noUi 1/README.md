version number : 595ff6cd41d0fb5f18d44dd86df62e2f655bded8

Thanks for giving me opportunity.


Start with npm install

For Compile : npm run js;

For Development Mode : grunt watch
"Watch task are applicable for both compile and test cases"

For coverage use : npm run test;

Entry File : app/index.js
Test Cases : test/*.js
Compiled : public/app.js

Covered almost all the test cases.



Automated build file for test cases and compiling is done with grunt tasks.


   