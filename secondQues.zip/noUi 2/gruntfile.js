module.exports = function (grunt) {
require("load-grunt-tasks")(grunt);
	grunt.initConfig({
		babel: {
			compile: {
				options: {
					presets: ['env']
				},
				files: {
					'public/app.js': 'app/*.js'
				}
			}
        },
    mochaTest: {
      test: {
        options: {
          require: [
        'babel-register'
         ],
          reporter: 'spec',
          clearRequireCache: true
        },
        src: ['test/*.js']
      },
    },
        watch: {
            scripts: {
              files: ['app/*.js','test/*.js'],
              tasks: ['babel','mochaTest'],
              options: {
                spawn: false,
              },
            },
          },
		
	});
    grunt.loadNpmTasks('grunt-mocha-test');
    grunt.loadNpmTasks('grunt-contrib-watch');
     
    grunt.registerTask('default', ['babel','mochaTest']);
    
    
}